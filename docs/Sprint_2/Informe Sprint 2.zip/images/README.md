Estructura de archivos de ejemplo, esta carpeta estaría destinada a 
guardar las imágenes usadas en el documento.
